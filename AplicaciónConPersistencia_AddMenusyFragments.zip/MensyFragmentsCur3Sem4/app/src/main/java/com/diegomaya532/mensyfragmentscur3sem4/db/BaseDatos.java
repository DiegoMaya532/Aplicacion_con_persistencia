package com.diegomaya532.mensyfragmentscur3sem4.db;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.annotation.Nullable;

import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;

import java.util.ArrayList;

public class BaseDatos extends SQLiteOpenHelper {
    private Context context;
    public BaseDatos(Context context) {
        super(context, ConstantesBaseDatos.DATABASE_NAME, null, ConstantesBaseDatos.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String queryCrearTablaContacto = "CREATE TABLE " + ConstantesBaseDatos.TABLE_MASCOTAS + " (" +
                ConstantesBaseDatos.TABLE_MASCOTAS_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE + " TEXT, " +
                ConstantesBaseDatos.TABLE_MASCOTAS_RAITING + " TEXT, " +
                ConstantesBaseDatos.TABLE_MASCOTAS_IMG + " INTEGER " +
                ")";
        String queryMascotaRaiting = "CREATE TABLE " + ConstantesBaseDatos.TABLE_RAITING + " (" +
                ConstantesBaseDatos.TABLE_RAITING_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ConstantesBaseDatos.TABLE_RAITING_ID_MASCOTA + " INTEGER, " +
                ConstantesBaseDatos.TABLE_RAITING_NUMERO_LIKES + " INTEGER, " +
                "FOREIGN KEY(" + ConstantesBaseDatos.TABLE_RAITING_ID_MASCOTA + ") " +
                "REFERENCES " + ConstantesBaseDatos.TABLE_MASCOTAS + "(" + ConstantesBaseDatos.TABLE_MASCOTAS_ID + ")"+
                ")";
        db.execSQL(queryCrearTablaContacto);
        db.execSQL(queryMascotaRaiting);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXIST " + ConstantesBaseDatos.TABLE_MASCOTAS);
        db.execSQL("DROP TABLE IF EXIST " + ConstantesBaseDatos.TABLE_RAITING);
    }

    public ArrayList<Mascota> obtenerTodasMascotas(){
        ArrayList<Mascota> mascotas = new ArrayList<Mascota>();
        String querySelect  = "SELECT * FROM " + ConstantesBaseDatos.TABLE_MASCOTAS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor registros = db.rawQuery(querySelect,null);
        while(registros.moveToNext()){
            Mascota mascotaActual = new Mascota();
            mascotaActual.setId(registros.getInt(0));
            mascotaActual.setNombre(registros.getString(1));
            //Numero de likes
            String query = "SELECT COUNT ("+ConstantesBaseDatos.TABLE_RAITING_NUMERO_LIKES+") as likes" +
                    " FROM " + ConstantesBaseDatos.TABLE_RAITING+
                    " WHERE " + ConstantesBaseDatos.TABLE_RAITING_ID_MASCOTA + " = " + mascotaActual.getId();
            Cursor cursor = db.rawQuery(query, null);
            if(cursor.moveToNext()){
               mascotaActual.setRaiting(String.valueOf(cursor.getInt(0)));
            }else{
                mascotaActual.setRaiting("0");
            }
            //mascotaActual.setRaiting(registros.getString(2));
            mascotaActual.setImagen(registros.getInt(3));
            mascotas.add(mascotaActual);
        }
        db.close();
        return mascotas;
    }

    public void insertarMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_MASCOTAS, null, contentValues);
        db.close();
    }
    public void insertarLikeMascota(ContentValues contentValues){
        SQLiteDatabase db = this.getWritableDatabase();
        db.insert(ConstantesBaseDatos.TABLE_RAITING, null, contentValues);
        db.close();
    }
    public int obtenerLikesMascota(Mascota mascota){
        int likes = 0;
        String query = "SELECT COUNT ("+ConstantesBaseDatos.TABLE_RAITING_NUMERO_LIKES+")" + " FROM " + ConstantesBaseDatos.TABLE_RAITING+
                " WHERE " + ConstantesBaseDatos.TABLE_RAITING_ID_MASCOTA + " = " + mascota.getId();
        SQLiteDatabase bd = this.getWritableDatabase();
        Cursor cursor = bd.rawQuery(query, null);
        if(cursor.moveToNext()){
            likes = cursor.getInt(0);
        }
        bd.close();
        return likes;
    }
    public int totalMascotas(){
        int count = 0;
        String query = "SELECT count(" +ConstantesBaseDatos.TABLE_MASCOTAS_ID+") FROM " + ConstantesBaseDatos.TABLE_MASCOTAS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);
        if(cursor.moveToNext()){
            count = cursor.getInt(0);
        }
        db.close();
        return  count;
    }
}
