package com.diegomaya532.mensyfragmentscur3sem4.db;

import android.content.ContentValues;
import android.content.Context;

import com.diegomaya532.mensyfragmentscur3sem4.R;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;

import java.util.ArrayList;

public class ConstructorMascotas {
    private Context contexto;
    public ConstructorMascotas(Context contexto) {
        this.contexto = contexto;
    }
    public ArrayList<Mascota> obtenerDatos(){
        ArrayList<Mascota> mascotas = new ArrayList<Mascota>();
        BaseDatos bd = new BaseDatos(contexto);
        /*mascotas.add(new Mascota("Jack", "5", R.drawable.dog_00));
        mascotas.add(new Mascota("Ronnie", "1", R.drawable.dog_01));
        mascotas.add(new Mascota("Bella", "3", R.drawable.dog_02));
        mascotas.add(new Mascota("Husher", "2", R.drawable.dog_03));
        mascotas.add(new Mascota("Rocket", "4", R.drawable.dog_04));*/
        if(totalMascotas()<5){
            insertarMascotas(bd);
        }
        return bd.obtenerTodasMascotas();
    }
    public void insertarMascotas(BaseDatos bd){
        ContentValues cV0 = new ContentValues();
        cV0.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Jack");
        cV0.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAITING, "0");
        cV0.put(ConstantesBaseDatos.TABLE_MASCOTAS_IMG, R.drawable.dog_00);
        bd.insertarMascota(cV0);
        ContentValues cV1 = new ContentValues();
        cV1.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Ronnie");
        cV1.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAITING, "0");
        cV1.put(ConstantesBaseDatos.TABLE_MASCOTAS_IMG, R.drawable.dog_01);
        bd.insertarMascota(cV1);
        ContentValues cV2 = new ContentValues();
        cV2.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Bella");
        cV2.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAITING, "0");
        cV2.put(ConstantesBaseDatos.TABLE_MASCOTAS_IMG, R.drawable.dog_02);
        bd.insertarMascota(cV2);
        ContentValues cV3 = new ContentValues();
        cV3.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Husher");
        cV3.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAITING, "0");
        cV3.put(ConstantesBaseDatos.TABLE_MASCOTAS_IMG, R.drawable.dog_03);
        bd.insertarMascota(cV3);
        ContentValues cV4 = new ContentValues();
        cV4.put(ConstantesBaseDatos.TABLE_MASCOTAS_NOMBRE, "Rocket");
        cV4.put(ConstantesBaseDatos.TABLE_MASCOTAS_RAITING, "0");
        cV4.put(ConstantesBaseDatos.TABLE_MASCOTAS_IMG, R.drawable.dog_04);
        bd.insertarMascota(cV4);
    }
    public void darLikeMascota(Mascota mascota){
        BaseDatos bd = new BaseDatos(contexto);
        ContentValues contentValues = new ContentValues();
        contentValues.put(ConstantesBaseDatos.TABLE_RAITING_ID_MASCOTA, mascota.getId());
        contentValues.put(ConstantesBaseDatos.TABLE_RAITING_NUMERO_LIKES, ConstantesBaseDatos.LIKE);
        bd.insertarLikeMascota(contentValues);
    }
    public int obtenerLikesMascota(Mascota mascota){
        BaseDatos bd = new BaseDatos(contexto);
        return bd.obtenerLikesMascota(mascota);
    }
    public int totalMascotas(){
        BaseDatos bd = new BaseDatos(contexto);
        return bd.totalMascotas();
    }
}
