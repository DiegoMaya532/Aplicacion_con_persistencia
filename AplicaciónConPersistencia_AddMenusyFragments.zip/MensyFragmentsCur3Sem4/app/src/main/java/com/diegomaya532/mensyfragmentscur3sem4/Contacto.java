package com.diegomaya532.mensyfragmentscur3sem4;

import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;


public class Contacto extends AppCompatActivity {
    private TextInputEditText inputNombre;
    private TextInputEditText inputCorreo;
    private TextInputEditText inputComentario;
    private Toolbar toolbar;
    private String nombre;
    private String correo;
    private String comentario;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacto);
        toolbar = findViewById(R.id.toolbar);
        TextView title = (TextView) findViewById(R.id.tvToolbar);
        title.setText(getResources().getString(R.string.menu_contacto));
        if(toolbar!=null) {
            setSupportActionBar(toolbar);
        }
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        inputNombre = (TextInputEditText) findViewById(R.id.inputNombre);
        inputCorreo = (TextInputEditText) findViewById(R.id.inputCorreo);
        inputComentario = (TextInputEditText) findViewById(R.id.inputComentario);
    }
    public void enviarComentario(View view){
        nombre = inputNombre.getText().toString();
        correo = inputCorreo.getText().toString();
        comentario = "NOMBRE: " + nombre + "\n" + "MENSAJE: "+ "\n" + inputComentario.getText().toString();
        Properties props = new Properties();
        props.put("mail.smtp.host", "my-mail-server");
        Session session = Session.getInstance(props, null);

        try {
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(getResources().getString(R.string.gmail));
            msg.setRecipients(Message.RecipientType.TO,
                    "diego-armando-99@hotmail.com");
            msg.setSubject("COMENTARIO DE APLICACION");
            msg.setSentDate(new Date());
            msg.setText(comentario);
            Transport.send(msg, getResources().getString(R.string.gmail), "@Xorp991019");
        } catch (MessagingException mex) {
            Toast.makeText(this, "Envío fallido, exception: " + mex, Toast.LENGTH_LONG).show();
        }
    }

}