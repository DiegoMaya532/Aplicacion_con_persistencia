package com.diegomaya532.mensyfragmentscur3sem4.presentador;

public interface iRecyclerViewFragmentPresenter {
    public void obtenerMascotasBD();
    public void mostrarMascotasRV();
}
