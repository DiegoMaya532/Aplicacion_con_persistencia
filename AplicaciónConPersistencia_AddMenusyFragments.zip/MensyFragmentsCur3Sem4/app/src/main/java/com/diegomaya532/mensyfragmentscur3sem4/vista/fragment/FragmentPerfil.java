package com.diegomaya532.mensyfragmentscur3sem4.vista.fragment;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.graphics.drawable.RoundedBitmapDrawable;
import android.support.v4.graphics.drawable.RoundedBitmapDrawableFactory;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.diegomaya532.mensyfragmentscur3sem4.adapter.AdaptadorTablaMascotas;
import com.diegomaya532.mensyfragmentscur3sem4.R;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;

import java.util.ArrayList;

public class FragmentPerfil extends Fragment {
    ArrayList<Mascota> mascotas;
    private RecyclerView tablaMascotas;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_perfil, container, false);
        Drawable originalDrawable = getResources().getDrawable(R.drawable.profile_dog);
        Bitmap originalBitmap = ((BitmapDrawable) originalDrawable).getBitmap();
        RoundedBitmapDrawable roundedDrawable = RoundedBitmapDrawableFactory.create(getResources(), originalBitmap);
        roundedDrawable.setCornerRadius(originalBitmap.getHeight());
        ImageView imageView = (ImageView) view.findViewById(R.id.imgPerfil);
        imageView.setImageDrawable(roundedDrawable);

        tablaMascotas = view.findViewById(R.id.rvPerfilMascota);
        GridLayoutManager glm = new GridLayoutManager(getActivity(),3);
        tablaMascotas.setLayoutManager(glm);
        mascotas = new ArrayList<Mascota>();
        mascotas.add(new Mascota("5", R.drawable.dog_00));
        mascotas.add(new Mascota("1", R.drawable.dog_01));
        mascotas.add(new Mascota("3", R.drawable.dog_02));
        mascotas.add(new Mascota("2", R.drawable.dog_03));
        mascotas.add(new Mascota("4", R.drawable.dog_04));
        AdaptadorTablaMascotas adaptadorTablaMascota = new AdaptadorTablaMascotas(mascotas, getActivity());
        tablaMascotas.setAdapter(adaptadorTablaMascota);
        return view;
    }
}