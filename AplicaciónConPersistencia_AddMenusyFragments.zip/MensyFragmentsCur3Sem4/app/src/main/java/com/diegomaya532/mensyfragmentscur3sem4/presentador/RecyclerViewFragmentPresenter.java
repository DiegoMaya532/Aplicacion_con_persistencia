package com.diegomaya532.mensyfragmentscur3sem4.presentador;

import android.content.Context;

import com.diegomaya532.mensyfragmentscur3sem4.db.ConstructorMascotas;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;
import com.diegomaya532.mensyfragmentscur3sem4.vista.fragment.iRecyclerViewFragmentView;

import java.util.ArrayList;

public class RecyclerViewFragmentPresenter implements iRecyclerViewFragmentPresenter{

    private iRecyclerViewFragmentView _iRecyclerViewFragmentView;
    private Context _context;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public RecyclerViewFragmentPresenter(iRecyclerViewFragmentView iRecyclerViewFragmentView, Context contexto) {
        _iRecyclerViewFragmentView = iRecyclerViewFragmentView;
        _context = contexto;
        obtenerMascotasBD();
    }

    @Override
    public void obtenerMascotasBD() {
        constructorMascotas = new ConstructorMascotas(_context);
        mascotas = constructorMascotas.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        _iRecyclerViewFragmentView.inicializarAdaptadorRecyclerView(_iRecyclerViewFragmentView.adaptadorListaMascota(mascotas));
        _iRecyclerViewFragmentView.generarLinearLayoutVertical();
    }
}
