package com.diegomaya532.mensyfragmentscur3sem4.vista.fragment;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.diegomaya532.mensyfragmentscur3sem4.adapter.AdaptadorListaMascota;
import com.diegomaya532.mensyfragmentscur3sem4.R;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;
import com.diegomaya532.mensyfragmentscur3sem4.presentador.RecyclerViewFragmentPresenter;
import com.diegomaya532.mensyfragmentscur3sem4.presentador.iRecyclerViewFragmentPresenter;

import java.util.ArrayList;

public class FragmentListaRecyclerView extends Fragment implements iRecyclerViewFragmentView{
    private ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    private iRecyclerViewFragmentPresenter presenter;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lista_recycler_view, container, false);
        listaMascotas = view.findViewById(R.id.rvMascotas);
        presenter = new RecyclerViewFragmentPresenter(this, getContext());
        return view;
    }

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);
    }

    @Override
    public AdaptadorListaMascota adaptadorListaMascota(ArrayList<Mascota> mascotas) {
        AdaptadorListaMascota adaptadorMascota = new AdaptadorListaMascota(mascotas, getActivity());
        return adaptadorMascota;
    }

    @Override
    public void inicializarAdaptadorRecyclerView(AdaptadorListaMascota adaptadorListaMascota) {
        listaMascotas.setAdapter(adaptadorListaMascota);
    }
}