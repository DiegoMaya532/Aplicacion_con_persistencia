package com.diegomaya532.mensyfragmentscur3sem4.adapter;

import android.app.Activity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.diegomaya532.mensyfragmentscur3sem4.R;
import com.diegomaya532.mensyfragmentscur3sem4.db.ConstructorMascotas;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;

import java.util.ArrayList;

public class AdaptadorListaMascota extends RecyclerView.Adapter<AdaptadorListaMascota.MascotasViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    //CONSTRUCTOR
    public AdaptadorListaMascota(ArrayList mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }
    @Override
    public MascotasViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_mascota, viewGroup, false);
        return new MascotasViewHolder(v);
    }

    @Override
    public void onBindViewHolder( MascotasViewHolder mascotasViewHolder, int i) {
        final Mascota mascota = mascotas.get(i);
        mascotasViewHolder.imgMascota.setImageResource(mascota.getImagen());
        mascotasViewHolder.tvNombre.setText(mascota.getNombre());
        mascotasViewHolder.tvRaiting.setText(mascota.getRaiting());
        mascotasViewHolder.imgMascota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Click en la imagen de la mascota
            }
        });
        mascotasViewHolder.imgLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Click en el botón like
                ConstructorMascotas cm = new ConstructorMascotas(activity);
                cm.darLikeMascota(mascota);
                mascotasViewHolder.tvRaiting.setText(String.valueOf(cm.obtenerLikesMascota(mascota)));
            }
        });
    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    //CLASE ESTÁTICA VIEW HOLDER
    public static class MascotasViewHolder extends RecyclerView.ViewHolder{
        //DECLARACIONES
        private ImageView imgMascota;
        private TextView tvNombre;
        private ImageView imgLike;
        private TextView tvRaiting;
        //CONSTRUCTOR DE LA CLASE ESTÁTICA
        public MascotasViewHolder(View itemView) {
            super(itemView);
            imgMascota = (ImageView)itemView.findViewById(R.id.imgMascotaCV);
            tvNombre = (TextView)itemView.findViewById(R.id.tvNombreMascotaCV);
            imgLike = (ImageView)itemView.findViewById(R.id.imgLikeCV);
            tvRaiting = (TextView) itemView.findViewById(R.id.tvRaitingMascotaCV);
        }
    }
}
