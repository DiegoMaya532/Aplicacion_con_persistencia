package com.diegomaya532.mensyfragmentscur3sem4.vista.fragment;
import com.diegomaya532.mensyfragmentscur3sem4.adapter.AdaptadorListaMascota;
import com.diegomaya532.mensyfragmentscur3sem4.pojo.Mascota;

import java.util.ArrayList;

public interface iRecyclerViewFragmentView {
    public void generarLinearLayoutVertical();
    public AdaptadorListaMascota adaptadorListaMascota(ArrayList<Mascota> mascotas);
    public void inicializarAdaptadorRecyclerView(AdaptadorListaMascota adaptadorListaMascota);
}
